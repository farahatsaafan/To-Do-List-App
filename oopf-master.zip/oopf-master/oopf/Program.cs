﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace oopf
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //string initialData = "";
            //// Application.Run(new Form1());
            //Task.Run(() => {
            //    // محاكاة لتحميل ملفات البرنامج أو الإعدادات
            //    System.Threading.Thread.Sleep(3000);
            //  //  initialData = "أهلاً بك في Orbit!";
            //}).Wait();

            //// بعد ما يخلص الـ 3 ثواني، يفتح الفورم الرئيسية
            Application.Run(new Form1());
        }
    }
}
