﻿namespace oopf
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pnlTop = new System.Windows.Forms.Panel();
            this.btnMin = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnmax = new System.Windows.Forms.Button();
            this.txtboxNameApp = new System.Windows.Forms.TextBox();
            this.pnlRight = new System.Windows.Forms.Panel();
            this.lblSuggestion = new System.Windows.Forms.Label();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.lblGmailUser = new System.Windows.Forms.Label();
            this.lblNameUser = new System.Windows.Forms.Label();
            this.pnlLeft = new System.Windows.Forms.Panel();
            this.btnPlanned = new Guna.UI2.WinForms.Guna2Button();
            this.btnTasks = new Guna.UI2.WinForms.Guna2Button();
            this.btnComplete = new Guna.UI2.WinForms.Guna2Button();
            this.btnAll = new Guna.UI2.WinForms.Guna2Button();
            this.btnImportant = new Guna.UI2.WinForms.Guna2Button();
            this.btnMyDay = new Guna.UI2.WinForms.Guna2Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.guna2TextBox1 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2CircleButton1 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.pnlBreak1 = new System.Windows.Forms.Panel();
            this.pnlmid = new System.Windows.Forms.Panel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.gunpnlAddTasks = new Guna.UI2.WinForms.Guna2Panel();
            this.gunCirclebtnTasks = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2TextBox2 = new Guna.UI2.WinForms.Guna2TextBox();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblFristNamelook = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.pnlTop.SuspendLayout();
            this.pnlRight.SuspendLayout();
            this.flowLayoutPanel2.SuspendLayout();
            this.pnlLeft.SuspendLayout();
            this.pnlmid.SuspendLayout();
            this.panel1.SuspendLayout();
            this.gunpnlAddTasks.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTop
            // 
            this.pnlTop.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlTop.Controls.Add(this.btnMin);
            this.pnlTop.Controls.Add(this.btnExit);
            this.pnlTop.Controls.Add(this.btnmax);
            this.pnlTop.Controls.Add(this.txtboxNameApp);
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(1840, 51);
            this.pnlTop.TabIndex = 0;
            // 
            // btnMin
            // 
            this.btnMin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMin.Font = new System.Drawing.Font("Marlett", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.btnMin.Location = new System.Drawing.Point(1670, 2);
            this.btnMin.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnMin.Name = "btnMin";
            this.btnMin.Size = new System.Drawing.Size(57, 49);
            this.btnMin.TabIndex = 0;
            this.btnMin.Text = "0";
            this.btnMin.UseVisualStyleBackColor = true;
            this.btnMin.Click += new System.EventHandler(this.btnMin_Click);
            // 
            // btnExit
            // 
            this.btnExit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.Font = new System.Drawing.Font("Marlett", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.btnExit.Location = new System.Drawing.Point(1782, 2);
            this.btnExit.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(58, 49);
            this.btnExit.TabIndex = 0;
            this.btnExit.Text = "r";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.button1_Click);
            this.btnExit.MouseEnter += new System.EventHandler(this.btnExit_MouseEnter);
            this.btnExit.MouseLeave += new System.EventHandler(this.btnExit_MouseLeave);
            // 
            // btnmax
            // 
            this.btnmax.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnmax.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnmax.Font = new System.Drawing.Font("Marlett", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.btnmax.Location = new System.Drawing.Point(1720, 2);
            this.btnmax.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnmax.Name = "btnmax";
            this.btnmax.Size = new System.Drawing.Size(63, 49);
            this.btnmax.TabIndex = 0;
            this.btnmax.Text = "2";
            this.btnmax.UseVisualStyleBackColor = true;
            this.btnmax.Click += new System.EventHandler(this.btnmax_Click);
            // 
            // txtboxNameApp
            // 
            this.txtboxNameApp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.txtboxNameApp.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtboxNameApp.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxNameApp.ForeColor = System.Drawing.Color.White;
            this.txtboxNameApp.Location = new System.Drawing.Point(48, 12);
            this.txtboxNameApp.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtboxNameApp.Name = "txtboxNameApp";
            this.txtboxNameApp.Size = new System.Drawing.Size(56, 24);
            this.txtboxNameApp.TabIndex = 4;
            this.txtboxNameApp.Text = "Orbit";
            // 
            // pnlRight
            // 
            this.pnlRight.Controls.Add(this.lblSuggestion);
            this.pnlRight.Controls.Add(this.flowLayoutPanel2);
            this.pnlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlRight.Location = new System.Drawing.Point(1264, 0);
            this.pnlRight.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pnlRight.Name = "pnlRight";
            this.pnlRight.Size = new System.Drawing.Size(576, 1063);
            this.pnlRight.TabIndex = 1;
            // 
            // lblSuggestion
            // 
            this.lblSuggestion.AutoSize = true;
            this.lblSuggestion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.lblSuggestion.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSuggestion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(244)))), ((int)(((byte)(245)))));
            this.lblSuggestion.Location = new System.Drawing.Point(4, 55);
            this.lblSuggestion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSuggestion.Name = "lblSuggestion";
            this.lblSuggestion.Size = new System.Drawing.Size(184, 40);
            this.lblSuggestion.TabIndex = 0;
            this.lblSuggestion.Text = "Suggestions";
            this.lblSuggestion.Click += new System.EventHandler(this.lblSuggestion_Click);
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flowLayoutPanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.flowLayoutPanel2.Controls.Add(this.button1);
            this.flowLayoutPanel2.Controls.Add(this.button2);
            this.flowLayoutPanel2.Controls.Add(this.button3);
            this.flowLayoutPanel2.Controls.Add(this.checkBox1);
            this.flowLayoutPanel2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.flowLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(576, 1058);
            this.flowLayoutPanel2.TabIndex = 1;
            this.flowLayoutPanel2.Paint += new System.Windows.Forms.PaintEventHandler(this.flowLayoutPanel2_Paint);
            // 
            // lblGmailUser
            // 
            this.lblGmailUser.AutoSize = true;
            this.lblGmailUser.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGmailUser.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblGmailUser.Location = new System.Drawing.Point(116, 118);
            this.lblGmailUser.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGmailUser.Name = "lblGmailUser";
            this.lblGmailUser.Size = new System.Drawing.Size(218, 23);
            this.lblGmailUser.TabIndex = 14;
            this.lblGmailUser.Text = "ahmednagj100@gmail.com";
            // 
            // lblNameUser
            // 
            this.lblNameUser.AutoSize = true;
            this.lblNameUser.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNameUser.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblNameUser.Location = new System.Drawing.Point(116, 80);
            this.lblNameUser.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNameUser.Name = "lblNameUser";
            this.lblNameUser.Size = new System.Drawing.Size(153, 31);
            this.lblNameUser.TabIndex = 13;
            this.lblNameUser.Text = "Ahmed Nagy";
            // 
            // pnlLeft
            // 
            this.pnlLeft.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlLeft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.pnlLeft.Controls.Add(this.btnPlanned);
            this.pnlLeft.Controls.Add(this.btnTasks);
            this.pnlLeft.Controls.Add(this.btnComplete);
            this.pnlLeft.Controls.Add(this.btnAll);
            this.pnlLeft.Controls.Add(this.btnImportant);
            this.pnlLeft.Controls.Add(this.btnMyDay);
            this.pnlLeft.Controls.Add(this.panel2);
            this.pnlLeft.Controls.Add(this.lblGmailUser);
            this.pnlLeft.Controls.Add(this.lblNameUser);
            this.pnlLeft.Controls.Add(this.guna2TextBox1);
            this.pnlLeft.Controls.Add(this.guna2CircleButton1);
            this.pnlLeft.Controls.Add(this.pnlBreak1);
            this.pnlLeft.Location = new System.Drawing.Point(0, 2);
            this.pnlLeft.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pnlLeft.Name = "pnlLeft";
            this.pnlLeft.Size = new System.Drawing.Size(624, 1062);
            this.pnlLeft.TabIndex = 2;
            this.pnlLeft.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlLeft_Paint);
            // 
            // btnPlanned
            // 
            this.btnPlanned.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.btnPlanned.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnPlanned.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnPlanned.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnPlanned.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnPlanned.FillColor = System.Drawing.Color.Transparent;
            this.btnPlanned.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnPlanned.ForeColor = System.Drawing.Color.White;
            this.btnPlanned.Image = global::oopf.Properties.Resources.diagram1;
            this.btnPlanned.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnPlanned.Location = new System.Drawing.Point(4, 605);
            this.btnPlanned.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnPlanned.Name = "btnPlanned";
            this.btnPlanned.Size = new System.Drawing.Size(620, 46);
            this.btnPlanned.TabIndex = 5;
            this.btnPlanned.Text = "Planned";
            this.btnPlanned.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnPlanned.Click += new System.EventHandler(this.btnPlanned_Click);
            // 
            // btnTasks
            // 
            this.btnTasks.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnTasks.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.btnTasks.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btnTasks.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnTasks.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnTasks.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnTasks.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnTasks.FillColor = System.Drawing.Color.Transparent;
            this.btnTasks.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTasks.ForeColor = System.Drawing.Color.White;
            this.btnTasks.Image = global::oopf.Properties.Resources.hut1;
            this.btnTasks.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnTasks.Location = new System.Drawing.Point(0, 548);
            this.btnTasks.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnTasks.Name = "btnTasks";
            this.btnTasks.Size = new System.Drawing.Size(624, 48);
            this.btnTasks.TabIndex = 4;
            this.btnTasks.Text = "Tasks";
            this.btnTasks.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnTasks.Click += new System.EventHandler(this.btnTasks_Click);
            // 
            // btnComplete
            // 
            this.btnComplete.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnComplete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.btnComplete.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btnComplete.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnComplete.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnComplete.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnComplete.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnComplete.FillColor = System.Drawing.Color.Transparent;
            this.btnComplete.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnComplete.ForeColor = System.Drawing.Color.White;
            this.btnComplete.Image = global::oopf.Properties.Resources.complete1;
            this.btnComplete.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnComplete.Location = new System.Drawing.Point(0, 491);
            this.btnComplete.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnComplete.Name = "btnComplete";
            this.btnComplete.Size = new System.Drawing.Size(624, 48);
            this.btnComplete.TabIndex = 2;
            this.btnComplete.Text = "Complete";
            this.btnComplete.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnComplete.Click += new System.EventHandler(this.btnComplete_Click);
            // 
            // btnAll
            // 
            this.btnAll.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAll.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.btnAll.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btnAll.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnAll.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnAll.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnAll.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnAll.FillColor = System.Drawing.Color.Transparent;
            this.btnAll.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAll.ForeColor = System.Drawing.Color.White;
            this.btnAll.Image = global::oopf.Properties.Resources.infinite1;
            this.btnAll.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnAll.Location = new System.Drawing.Point(0, 429);
            this.btnAll.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnAll.Name = "btnAll";
            this.btnAll.Size = new System.Drawing.Size(624, 52);
            this.btnAll.TabIndex = 3;
            this.btnAll.Text = "All";
            this.btnAll.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnAll.Click += new System.EventHandler(this.btnAll_Click_1);
            // 
            // btnImportant
            // 
            this.btnImportant.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnImportant.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.btnImportant.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btnImportant.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnImportant.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnImportant.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnImportant.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnImportant.FillColor = System.Drawing.Color.Transparent;
            this.btnImportant.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnImportant.ForeColor = System.Drawing.Color.White;
            this.btnImportant.Image = global::oopf.Properties.Resources.star__2_;
            this.btnImportant.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnImportant.Location = new System.Drawing.Point(0, 365);
            this.btnImportant.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnImportant.Name = "btnImportant";
            this.btnImportant.Size = new System.Drawing.Size(624, 55);
            this.btnImportant.TabIndex = 1;
            this.btnImportant.Text = "important";
            this.btnImportant.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnImportant.Click += new System.EventHandler(this.btnImportant_Click);
            // 
            // btnMyDay
            // 
            this.btnMyDay.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMyDay.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.btnMyDay.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btnMyDay.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnMyDay.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnMyDay.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnMyDay.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnMyDay.FillColor = System.Drawing.Color.Empty;
            this.btnMyDay.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMyDay.ForeColor = System.Drawing.Color.White;
            this.btnMyDay.Image = global::oopf.Properties.Resources.sun1;
            this.btnMyDay.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnMyDay.Location = new System.Drawing.Point(-76, 580);
            this.btnMyDay.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnMyDay.Name = "btnMyDay";
            this.btnMyDay.Size = new System.Drawing.Size(624, 54);
            this.btnMyDay.TabIndex = 0;
            this.btnMyDay.Text = "My Day";
            this.btnMyDay.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnMyDay.Click += new System.EventHandler(this.btnMyDay_Click);
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.Location = new System.Drawing.Point(624, 49);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(638, 95);
            this.panel2.TabIndex = 4;
            // 
            // guna2TextBox1
            // 
            this.guna2TextBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2TextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.guna2TextBox1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.guna2TextBox1.BorderRadius = 5;
            this.guna2TextBox1.BorderThickness = 0;
            this.guna2TextBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox1.DefaultText = "";
            this.guna2TextBox1.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox1.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.guna2TextBox1.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TextBox1.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox1.IconRight = global::oopf.Properties.Resources.magnifying_glass1;
            this.guna2TextBox1.Location = new System.Drawing.Point(33, 238);
            this.guna2TextBox1.Margin = new System.Windows.Forms.Padding(6, 8, 6, 8);
            this.guna2TextBox1.Name = "guna2TextBox1";
            this.guna2TextBox1.PlaceholderText = "Search";
            this.guna2TextBox1.SelectedText = "";
            this.guna2TextBox1.Size = new System.Drawing.Size(556, 54);
            this.guna2TextBox1.TabIndex = 6;
            this.guna2TextBox1.TextChanged += new System.EventHandler(this.guna2TextBox1_TextChanged);
            // 
            // guna2CircleButton1
            // 
            this.guna2CircleButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.guna2CircleButton1.BorderColor = System.Drawing.Color.White;
            this.guna2CircleButton1.BorderThickness = 2;
            this.guna2CircleButton1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2CircleButton1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2CircleButton1.FillColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2CircleButton1.ForeColor = System.Drawing.Color.White;
            this.guna2CircleButton1.Image = global::oopf.Properties.Resources.add_photo__1_;
            this.guna2CircleButton1.ImageSize = new System.Drawing.Size(30, 30);
            this.guna2CircleButton1.Location = new System.Drawing.Point(18, 58);
            this.guna2CircleButton1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.guna2CircleButton1.Name = "guna2CircleButton1";
            this.guna2CircleButton1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton1.Size = new System.Drawing.Size(88, 97);
            this.guna2CircleButton1.TabIndex = 15;
            // 
            // pnlBreak1
            // 
            this.pnlBreak1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlBreak1.Location = new System.Drawing.Point(4, 228);
            this.pnlBreak1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pnlBreak1.Name = "pnlBreak1";
            this.pnlBreak1.Size = new System.Drawing.Size(620, 2);
            this.pnlBreak1.TabIndex = 16;
            // 
            // pnlmid
            // 
            this.pnlmid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlmid.AutoScroll = true;
            this.pnlmid.BackColor = System.Drawing.Color.Transparent;
            this.pnlmid.Controls.Add(this.flowLayoutPanel1);
            this.pnlmid.Location = new System.Drawing.Point(624, 51);
            this.pnlmid.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pnlmid.Name = "pnlmid";
            this.pnlmid.Size = new System.Drawing.Size(638, 1012);
            this.pnlmid.TabIndex = 5;
            this.pnlmid.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlmid_Paint);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 105);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(638, 817);
            this.flowLayoutPanel1.TabIndex = 0;
            this.flowLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.flowLayoutPanel1_Paint);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.panel1.Controls.Add(this.gunpnlAddTasks);
            this.panel1.Controls.Add(this.lblDate);
            this.panel1.Controls.Add(this.lblFristNamelook);
            this.panel1.Controls.Add(this.pnlmid);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1840, 1063);
            this.panel1.TabIndex = 5;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // gunpnlAddTasks
            // 
            this.gunpnlAddTasks.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gunpnlAddTasks.BackColor = System.Drawing.Color.Transparent;
            this.gunpnlAddTasks.Controls.Add(this.gunCirclebtnTasks);
            this.gunpnlAddTasks.Controls.Add(this.guna2TextBox2);
            this.gunpnlAddTasks.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            this.gunpnlAddTasks.ForeColor = System.Drawing.Color.Transparent;
            this.gunpnlAddTasks.Location = new System.Drawing.Point(628, 982);
            this.gunpnlAddTasks.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gunpnlAddTasks.Name = "gunpnlAddTasks";
            this.gunpnlAddTasks.Size = new System.Drawing.Size(633, 77);
            this.gunpnlAddTasks.TabIndex = 4;
            this.gunpnlAddTasks.UseTransparentBackground = true;
            // 
            // gunCirclebtnTasks
            // 
            this.gunCirclebtnTasks.BackColor = System.Drawing.Color.Transparent;
            this.gunCirclebtnTasks.BorderColor = System.Drawing.Color.Gray;
            this.gunCirclebtnTasks.BorderThickness = 2;
            this.gunCirclebtnTasks.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.gunCirclebtnTasks.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.gunCirclebtnTasks.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.gunCirclebtnTasks.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.gunCirclebtnTasks.FillColor = System.Drawing.Color.Transparent;
            this.gunCirclebtnTasks.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunCirclebtnTasks.ForeColor = System.Drawing.Color.Transparent;
            this.gunCirclebtnTasks.Location = new System.Drawing.Point(32, 23);
            this.gunCirclebtnTasks.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gunCirclebtnTasks.Name = "gunCirclebtnTasks";
            this.gunCirclebtnTasks.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.gunCirclebtnTasks.Size = new System.Drawing.Size(30, 31);
            this.gunCirclebtnTasks.TabIndex = 1;
            this.gunCirclebtnTasks.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.gunCirclebtnTasks.UseTransparentBackground = true;
            this.gunCirclebtnTasks.Click += new System.EventHandler(this.guna2CircleButton2_Click);
            // 
            // guna2TextBox2
            // 
            this.guna2TextBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2TextBox2.Animated = true;
            this.guna2TextBox2.AutoRoundedCorners = true;
            this.guna2TextBox2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            this.guna2TextBox2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox2.DefaultText = "";
            this.guna2TextBox2.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox2.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox2.FillColor = System.Drawing.Color.DimGray;
            this.guna2TextBox2.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TextBox2.ForeColor = System.Drawing.Color.Transparent;
            this.guna2TextBox2.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox2.Location = new System.Drawing.Point(0, 0);
            this.guna2TextBox2.Margin = new System.Windows.Forms.Padding(6, 8, 6, 8);
            this.guna2TextBox2.Name = "guna2TextBox2";
            this.guna2TextBox2.PlaceholderForeColor = System.Drawing.Color.Transparent;
            this.guna2TextBox2.PlaceholderText = "";
            this.guna2TextBox2.SelectedText = "";
            this.guna2TextBox2.Size = new System.Drawing.Size(633, 77);
            this.guna2TextBox2.TabIndex = 1;
            this.guna2TextBox2.TextOffset = new System.Drawing.Point(40, 0);
            this.guna2TextBox2.TextChanged += new System.EventHandler(this.guna2TextBox2_TextChanged);
            this.guna2TextBox2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.guna2TextBox2_KeyDown);
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.BackColor = System.Drawing.Color.Transparent;
            this.lblDate.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblDate.Location = new System.Drawing.Point(633, 115);
            this.lblDate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(75, 28);
            this.lblDate.TabIndex = 2;
            this.lblDate.Text = "lblDate";
            // 
            // lblFristNamelook
            // 
            this.lblFristNamelook.AutoSize = true;
            this.lblFristNamelook.BackColor = System.Drawing.Color.Transparent;
            this.lblFristNamelook.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFristNamelook.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblFristNamelook.Location = new System.Drawing.Point(628, 60);
            this.lblFristNamelook.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFristNamelook.Name = "lblFristNamelook";
            this.lblFristNamelook.Size = new System.Drawing.Size(122, 40);
            this.lblFristNamelook.TabIndex = 1;
            this.lblFristNamelook.Text = "My Day";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(3, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(84, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(53, 47);
            this.button2.TabIndex = 5;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(143, 3);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 6;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(224, 3);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(113, 24);
            this.checkBox1.TabIndex = 0;
            this.checkBox1.Text = "checkBox1";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.ClientSize = new System.Drawing.Size(1840, 1063);
            this.Controls.Add(this.pnlTop);
            this.Controls.Add(this.pnlLeft);
            this.Controls.Add(this.pnlRight);
            this.Controls.Add(this.panel1);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.pnlRight.ResumeLayout(false);
            this.pnlRight.PerformLayout();
            this.flowLayoutPanel2.ResumeLayout(false);
            this.flowLayoutPanel2.PerformLayout();
            this.pnlLeft.ResumeLayout(false);
            this.pnlLeft.PerformLayout();
            this.pnlmid.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.gunpnlAddTasks.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnmax;
        private System.Windows.Forms.Button btnMin;
        private System.Windows.Forms.Panel pnlRight;
        private System.Windows.Forms.Panel pnlLeft;
        private System.Windows.Forms.TextBox txtboxNameApp;
        private System.Windows.Forms.Panel panel1;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox1;
        private System.Windows.Forms.Label lblGmailUser;
        private System.Windows.Forms.Label lblNameUser;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton1;
        private System.Windows.Forms.Panel pnlBreak1;
        private System.Windows.Forms.Label lblSuggestion;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.Label lblDate;
        private Guna.UI2.WinForms.Guna2Panel gunpnlAddTasks;
        private Guna.UI2.WinForms.Guna2CircleButton gunCirclebtnTasks;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox2;
        private System.Windows.Forms.Panel pnlmid;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblFristNamelook;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private Guna.UI2.WinForms.Guna2Button btnTasks;
        private Guna.UI2.WinForms.Guna2Button btnComplete;
        private Guna.UI2.WinForms.Guna2Button btnAll;
        private Guna.UI2.WinForms.Guna2Button btnImportant;
        private Guna.UI2.WinForms.Guna2Button btnMyDay;
        private Guna.UI2.WinForms.Guna2Button btnPlanned;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.CheckBox checkBox1;
    }
}

