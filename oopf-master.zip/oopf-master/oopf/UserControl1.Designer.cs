﻿namespace oopf
{
    partial class TasksItem
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCheckComplete = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2ImageCheckBox1 = new Guna.UI2.WinForms.Guna2ImageCheckBox();
            this.lblTaskName = new System.Windows.Forms.Label();
            this.guna2Panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCheckComplete
            // 
            this.btnCheckComplete.BackColor = System.Drawing.Color.Transparent;
            this.btnCheckComplete.BorderColor = System.Drawing.Color.Gray;
            this.btnCheckComplete.BorderThickness = 2;
            this.btnCheckComplete.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnCheckComplete.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnCheckComplete.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnCheckComplete.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnCheckComplete.FillColor = System.Drawing.Color.Transparent;
            this.btnCheckComplete.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnCheckComplete.ForeColor = System.Drawing.Color.White;
            this.btnCheckComplete.Location = new System.Drawing.Point(12, 13);
            this.btnCheckComplete.Name = "btnCheckComplete";
            this.btnCheckComplete.PressedDepth = 20;
            this.btnCheckComplete.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.btnCheckComplete.Size = new System.Drawing.Size(23, 23);
            this.btnCheckComplete.TabIndex = 0;
            this.btnCheckComplete.UseTransparentBackground = true;
            this.btnCheckComplete.Click += new System.EventHandler(this.guna2CircleButton1_Click);
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Panel1.AutoScroll = true;
            this.guna2Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(150)))));
            this.guna2Panel1.Controls.Add(this.guna2ImageCheckBox1);
            this.guna2Panel1.Controls.Add(this.lblTaskName);
            this.guna2Panel1.FillColor = System.Drawing.Color.DimGray;
            this.guna2Panel1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.guna2Panel1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.guna2Panel1.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.Size = new System.Drawing.Size(422, 50);
            this.guna2Panel1.TabIndex = 1;
            this.guna2Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.guna2Panel1_Paint);
            // 
            // guna2ImageCheckBox1
            // 
            this.guna2ImageCheckBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ImageCheckBox1.CheckedState.Image = global::oopf.Properties.Resources.star__3_;
            this.guna2ImageCheckBox1.Image = global::oopf.Properties.Resources.stars1;
            this.guna2ImageCheckBox1.ImageOffset = new System.Drawing.Point(0, 0);
            this.guna2ImageCheckBox1.ImageRotate = 0F;
            this.guna2ImageCheckBox1.Location = new System.Drawing.Point(383, 3);
            this.guna2ImageCheckBox1.Name = "guna2ImageCheckBox1";
            this.guna2ImageCheckBox1.Size = new System.Drawing.Size(36, 44);
            this.guna2ImageCheckBox1.TabIndex = 1;
            this.guna2ImageCheckBox1.CheckedChanged += new System.EventHandler(this.guna2ImageCheckBox1_CheckedChanged);
            // 
            // lblTaskName
            // 
            this.lblTaskName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTaskName.AutoSize = true;
            this.lblTaskName.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTaskName.Location = new System.Drawing.Point(54, 16);
            this.lblTaskName.Name = "lblTaskName";
            this.lblTaskName.Size = new System.Drawing.Size(37, 17);
            this.lblTaskName.TabIndex = 0;
            this.lblTaskName.Text = "tasks";
            // 
            // TasksItem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.btnCheckComplete);
            this.Controls.Add(this.guna2Panel1);
            this.Name = "TasksItem";
            this.Size = new System.Drawing.Size(422, 50);
            this.guna2Panel1.ResumeLayout(false);
            this.guna2Panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2CircleButton btnCheckComplete;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private System.Windows.Forms.Label lblTaskName;
        private Guna.UI2.WinForms.Guna2ImageCheckBox guna2ImageCheckBox1;
    }
}
