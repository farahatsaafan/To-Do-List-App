﻿using Guna.UI2.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace oopf
{
    public partial class TasksItem : UserControl
    {
        public TasksItem()
        {
            InitializeComponent();
        }

        private void guna2Panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        public string TaskName
        {
            get { return lblTaskName.Text; }
            set { lblTaskName.Text = value; }
        }
        public bool IsCompleted = false; // في البداية المهمة مش خلصانة
        private void guna2CircleButton1_Click(object sender, EventArgs e)
        {
            if (lblTaskName.Font.Strikeout == true)
            {
                // 1. لو مشطوب، نرجعه لحالته الطبيعية (مهمة لسه مخلصتش)
                lblTaskName.Font = new Font(lblTaskName.Font, FontStyle.Regular);
                lblTaskName.ForeColor = Color.White; // أو اللون الفاتح بتاعك

                // نرجع الدايرة شفافة تاني
                btnCheckComplete.FillColor = Color.Transparent;
                IsCompleted = false;
            }
            else
            {
                // 2. لو مش مشطوب، نشطب عليه (مهمة خلصت)
                lblTaskName.Font = new Font(lblTaskName.Font, FontStyle.Strikeout);
                lblTaskName.ForeColor = Color.Gray; // نبهت لون الكلمة عشان تبان إنها خلصت

                // نلون الدايرة عشان تبان إنها اتعلم عليها (مثلاً أخضر أو أزرق)
                btnCheckComplete.FillColor = Color.FromArgb(45, 149, 150); // أو أي لون يعجبك
                IsCompleted = true;
            }

        }

        public bool IsImportant = false;

        private void guna2ImageCheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            // لو النجمة اتعلم عليها، خلي المتغير بـ true، ولو اتلغت خليه false
            IsImportant = guna2ImageCheckBox1.Checked;

        }
        public DateTime TaskDate = DateTime.Now;
        public bool IsPlanned = false;
        public bool IsMyDayTask = false; // عشان نعرف دي مهمة بتاعة My Day ولا المهام العادية

        public bool IsAllTask = false;

        










    }





}
////if (label1.Font.Strikeout == true)
//{
//    // ... (الكود القديم بتاعك زي ما هو هنا) ...

//    IsCompleted = false; // زود السطر ده بس
//}
//    else
//{
//    // ... (الكود القديم بتاعك زي ما هو هنا) ...

//    IsCompleted = true; // وزود السطر ده بس
//}