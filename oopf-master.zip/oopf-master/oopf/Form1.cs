﻿using Guna.UI2.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace oopf
{
    public partial class Form1 : Form
    {
       // string receivedData;
        public Form1()
        {
            InitializeComponent();
           // receivedData = data; // حفظنا الداتا
            // الكود السحري لتسريع السكرول ومنع التقطيع
          //  typeof(Control).GetProperty("DoubleBuffered", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance).SetValue(flowLayoutPanel1, true, null);
            // السطر ده بيخلي الزرار ياخد شكل الـ (Active) وينور
            btnMyDay.Checked = true;

            // السطر ده سحري: بينفذ أي كود إنت هتكتبه جوه الزرار مستقبلاً كأن اليوزر داس عليه بالماوس!
            btnMyDay.PerformClick();
        }
        //protected override CreateParams CreateParams
        //{
        //    get
        //    {
        //        CreateParams cp = base.CreateParams;
        //        // السطر ده بيجبر الويندوز يدمج الطبقات الشفافة بسرعة كارت الشاشة
        //        cp.ExStyle |= 0x02000000; // WS_EX_COMPOSITED
        //        return cp;
        //    }
        //}


        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void btnExit_MouseEnter(object sender, EventArgs e)
        {
            btnExit.BackColor = Color.Red;
            btnExit.ForeColor = Color.Black; // بيخلي حرف الـ X لونه أبيض عشان يبان على الأحمر
        }

        private void btnExit_MouseLeave(object sender, EventArgs e)
        {
            btnExit.BackColor = Color.Transparent; // أو أي لون إنت كنت حاطه للخلفية
            btnExit.ForeColor = Color.Black; // رجع لون حرف الـ X زي ما كان
        }

        private void btnmax_Click(object sender, EventArgs e)
        {
            // لو الشاشة في حجمها الطبيعي، كبرها لتملى الشاشة
            if (this.WindowState == FormWindowState.Normal)
            {
                this.WindowState = FormWindowState.Maximized;
            }
            // لو الشاشة متكبرة أصلاً، رجعها لحجمها العادي
            else
            {
                this.WindowState = FormWindowState.Normal;
            }
        }

        private void btnMin_Click(object sender, EventArgs e)
        {
            // الكود ده بينزل البرنامج في شريط المهام تحت
            this.WindowState = FormWindowState.Minimized;
        }

       

        private void btnAll_Click(object sender, EventArgs e)
        {

        }

       

       

        private void lblSuggestion_Click(object sender, EventArgs e)
        {
                                                            
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }
        

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // عرض التاريخ الحالي وتنسيقه بالشكل المطلوب
            lblDate.Text = DateTime.Now.ToString("dddd, MMMM d", new System.Globalization.CultureInfo("en-US"));
            // أول ما الفورم تفتح، الداتا هتكون موجودة فوراً
          //  lblFristNamelook.Text = receivedData;
        }

       

        private void guna2CircleButton2_Click(object sender, EventArgs e)
        {
            lblFristNamelook.Text = "Complete"; // بنغير العنوان زي ما اتفقنا

            // بنلف على كل حاجة جوه البانل بتاع المهام
            foreach (Control ctrl in flowLayoutPanel1.Controls)
            {
                // بنتأكد إن الحاجة دي عبارة عن مهمة (TasksItem)
                if (ctrl is TasksItem)
                {
                    TasksItem task = (TasksItem)ctrl; // بنحولها لمهمة عشان نقرأ بياناتها

                    // لو المهمة خلصانة، اظهرها.. لو لأ، اخفيها
                    if (task.IsCompleted == true)
                    {
                        task.Visible = true;
                    }
                    else
                    {
                        task.Visible = false;
                    }
                }
            }
        }

        private void guna2TextBox2_KeyDown(object sender, KeyEventArgs e)
        {
            TasksItem newTask = new TasksItem();
            // لو داس إنتر والمربع مش فاضي
            if (e.KeyCode == Keys.Enter && guna2TextBox2.Text != "")
            {

               
                newTask.TaskName = guna2TextBox2.Text;

                // السطر الإجباري للحجم
                newTask.Size = new Size(flowLayoutPanel1.ClientSize.Width - 25, newTask.Height);

                flowLayoutPanel1.Controls.Add(newTask);
                guna2TextBox2.Text = "";
                e.SuppressKeyPress = true;
            }
            if (lblFristNamelook.Text == "My Day")
            {
                newTask.IsMyDayTask = true;
            }
            else if (lblFristNamelook.Text == "Planned")
            {
                newTask.IsPlanned = true;
            }
            else if (lblFristNamelook.Text == "All")
            {
                newTask.IsAllTask = true; // السطر ده اللي هيمنعها تروح للـ Tasks!
            }
        }

        private void flowLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnlLeft_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnMyDay_Click(object sender, EventArgs e)
        {
            lblFristNamelook.Text = "My Day";
            lblFristNamelook.ForeColor = Color.Black;

            // بناخد نسخة عشان نقدر ننقل المهام للـ Suggestions (flowLayoutPanel2) من غير ما يحصل Crash
            var myTasks = flowLayoutPanel1.Controls.OfType<TasksItem>().ToList();

            foreach (TasksItem task in myTasks)
            {
                TimeSpan timePassed = DateTime.Now - task.TaskDate;

                // 1. لو دي مهمة مقفولة (بتاعت Tasks الخام) نتجاهلها ونخفيها
                if (task.IsMyDayTask == false && task.IsPlanned == false)
                {
                    task.Visible = false;
                    continue;
                }

                // 2. لو المهمة بتاعت My Day وعدى عليها 24 ساعة ومخلصتش -> تروح للاقتراحات
                if (task.IsMyDayTask == true && timePassed.TotalHours >= 24 && task.IsCompleted == false)
                {
                    task.Visible = true;
                    flowLayoutPanel1.Controls.Remove(task); // نشيلها من البانل الأساسي
                    flowLayoutPanel2.Controls.Add(task);    // نحطها في الاقتراحات
                }
                // 3. لو لسه معداش 24 ساعة (أو) هي متخطط ليها (Planned) -> تظهر عادي في My Day
                else if ((task.IsMyDayTask == true && timePassed.TotalHours < 24) || task.IsPlanned == true)
                {
                    task.Visible = true;
                }
                else
                {
                    task.Visible = false;
                }
            }

            // نظهر مهام الاقتراحات عشان لو كانت مخفية من زرار تاني
            foreach (Control ctrl in flowLayoutPanel2.Controls) { ctrl.Visible = true; }
            //lblFristNamelook.Text = "My Day";

            //// التريكة هنا: بناخد نسخة من المهام في (List) عشان لما ننقل مهمة البرنامج ميهنجش


            //// بناخد نسخة من المهام في List عشان البرنامج ميكراشش وإحنا بننقلها


            //var myTasks = flowLayoutPanel1.Controls.OfType<TasksItem>().ToList();

            //foreach (TasksItem task in myTasks)
            //{
            //    TimeSpan timePassed = DateTime.Now - task.TaskDate;

            //    // التريكة هنا: لو دي مهمة من مهام Tasks الخام، اخفيها وتجاهلها تماماً! (عشان متخرجش منه)
            //    if (task.IsCompleted == false && task.IsPlanned == false && task.IsImportant == false && task.IsMyDayTask == false)
            //    {
            //        task.Visible = false;
            //        continue; // كمل اللفة ومتحسبلهاش وقت ولا تنقلها
            //    }

            //    // الحسبة بتاعت My Day بس (للمهام اللي اتكتبت جواه أو المتخطط لها):
            //    if (task.IsMyDayTask == true && timePassed.TotalHours >= 24 && task.IsCompleted == false)
            //    {
            //        task.Visible = true;
            //        flowLayoutPanel2.Controls.Add(task); // تروح الاقتراحات
            //    }
            //    else if ((task.IsMyDayTask == true && timePassed.TotalHours < 24) || task.IsPlanned == true)
            //    {
            //        task.Visible = true; // تفضل في My Day
            //    }
            //    else
            //    {
            //        task.Visible = false;
            //    }
            //    //foreach (Control ctrl in flowLayoutPanel1.Controls)
            //    //{
            //    //    ctrl.Visible = true;
            //    //}
            //}
            //  على كل المهام ونظهرها كلها بلا استثناء
            //foreach (Control ctrl in flowLayoutPanel1.Controls)
            //{
            //    ctrl.Visible = true;
            //}
            // lblTitle.Text = "My Day";

            //foreach (Control ctrl in flowLayoutPanel1.Controls)
            //{
            //    if (ctrl is TasksItem)
            //    {
            //        TasksItem task = (TasksItem)ctrl;

            //        // هنا بنحسب الفرق بين الوقت الحالي، والوقت اللي المهمة اتعملت فيه
            //        TimeSpan timePassed = DateTime.Now - task.TaskDate;

            //        // بنسأل: هل عدى عليها أقل من 24 ساعة؟ (أو) هل هي متخطط لها؟
            //        if (timePassed.TotalHours < 24 || task.IsPlanned == true)
            //        {
            //            task.Visible = true; // اظهرها
            //        }
            //        else
            //        {
            //            task.Visible = false; // اخفيها عشان قديمة
            //        }
            //    }
            //}
            //lblFristNamelook.Text = "My Day";
           // lblFristNamelook.ForeColor = Color.Black; // يغير لون الكلمة لأزرق شيك
        }

        private void btnImportant_Click(object sender, EventArgs e)
        {
            lblFristNamelook.Text = "Important";

            foreach (Control ctrl in flowLayoutPanel1.Controls)
            {
                if (ctrl is TasksItem task) task.Visible = task.IsImportant;
            }

            foreach (Control ctrl in flowLayoutPanel2.Controls)
            {
                if (ctrl is TasksItem task) task.Visible = task.IsImportant;
            }
            //lblFristNamelook.Text = "Important";

            //// نلف على البانل الأساسي
            //foreach (Control ctrl in flowLayoutPanel1.Controls)
            //{
            //    if (ctrl is TasksItem task) task.Visible = task.IsImportant;
            //}

            //// نلف على بانل الاقتراحات كمان
            //foreach (Control ctrl in flowLayoutPanel2.Controls)
            //{
            //    if (ctrl is TasksItem task) task.Visible = task.IsImportant;
            //}
        }

        private void btnAll_Click_1(object sender, EventArgs e)
        {

       
        
            lblFristNamelook.Text = "All";
            lblFristNamelook.ForeColor = Color.Black;

            foreach (Control ctrl in flowLayoutPanel1.Controls)
            {
                if (ctrl is TasksItem task)
                {
                    // هنا ضفنا الـ IsAllTask عشان يظهر المهام اللي اتكتبت جواه
                    task.Visible = (task.IsMyDayTask || task.IsPlanned || task.IsAllTask);
                }
            }

            foreach (Control ctrl in flowLayoutPanel2.Controls)
            {
                if (ctrl is TasksItem task)
                    task.Visible = (task.IsMyDayTask || task.IsPlanned || task.IsAllTask);
            }
        
           
            //lblFristNamelook.ForeColor = Color.Black;

            //// All بيعرض كل حاجة "ما عدا" المهام المقفولة بتاعت زرار Tasks
            //foreach (Control ctrl in flowLayoutPanel1.Controls)
            //{
            //    if (ctrl is TasksItem task)
            //    {
            //        task.Visible = (task.IsMyDayTask || task.IsPlanned);
            //    }
            //}

            //// وبنطبق نفس الكلام على الاقتراحات
            //foreach (Control ctrl in flowLayoutPanel2.Controls)
            //{
            //    if (ctrl is TasksItem task) task.Visible = (task.IsMyDayTask || task.IsPlanned);
            //}
            ////lblFristNamelook.Text = "All";
            //foreach (Control ctrl in flowLayoutPanel1.Controls)
            //{
            //    ctrl.Visible = true;
            //}
            //lblFristNamelook.ForeColor = Color.Black; // يغير لون الكلمة للون الافتراضي

            //// وبنظهر كل اللي اترمى في بانل الاقتراحات كمان
            //foreach (Control ctrl in flowLayoutPanel2.Controls)
            //{
            //    ctrl.Visible = true;
            //}
        }

        private void btnComplete_Click(object sender, EventArgs e)
        {

            lblFristNamelook.Text = "Complete";

            foreach (Control ctrl in flowLayoutPanel1.Controls)
            {
                if (ctrl is TasksItem task) task.Visible = task.IsCompleted;
            }

            foreach (Control ctrl in flowLayoutPanel2.Controls)
            {
                if (ctrl is TasksItem task) task.Visible = task.IsCompleted;
            }
            //lblFristNamelook.Text = "Complete";
            //// بنغير العنوان زي ما اتفقنا



            //foreach (Control ctrl in flowLayoutPanel1.Controls)
            //{
            //    if (ctrl is TasksItem task)
            //    {
            //        task.Visible = task.IsCompleted;
            //    }
            //}
        }

        private void btnTasks_Click(object sender, EventArgs e)
        {
            lblFristNamelook.Text = "Tasks";

            foreach (Control ctrl in flowLayoutPanel1.Controls)
            {
                if (ctrl is TasksItem task)
                {
                    // المهمة المقفولة دلوقتي هي اللي معلهاش ولا ختم من التلاتة!
                    task.Visible = (task.IsMyDayTask == false && task.IsPlanned == false && task.IsAllTask == false);
                }
            }

            foreach (Control ctrl in flowLayoutPanel2.Controls) { ctrl.Visible = false; }
            //    lblFristNamelook.Text = "Tasks";

            //    foreach (Control ctrl in flowLayoutPanel1.Controls)
            //    {
            //        if (ctrl is TasksItem task)
            //        {
            //            // المهمة المقفولة هي اللي مش تبع My Day ومش Planned
            //            task.Visible = (task.IsMyDayTask == false && task.IsPlanned == false);
            //        }
            //    }

            //    // مهام Tasks مش بتروح الاقتراحات، فنخفي البانل ده خالص
            //    foreach (Control ctrl in flowLayoutPanel2.Controls) { ctrl.Visible = false; }
            //    //lblFristNamelook.Text = "Tasks";


            //foreach (Control ctrl in flowLayoutPanel1.Controls)
            //{
            //    if (ctrl is TasksItem task)
            //    {
            //        // لو المهمة مخلصتش، ومش متخطط لها، ومفيش عليها نجمة.. تظهر هنا
            //        if (task.IsCompleted == false && task.IsPlanned == false && task.IsImportant == false)
            //        {
            //            task.Visible = true;
            //        }
            //        else
            //        {
            //            // أي حاجة تانية (مهمة، خلصانة، متخطط لها) ممنوع تدخل هنا!
            //            task.Visible = false;
            //        }
            //    }
            //}







        }

        private void btnPlanned_Click(object sender, EventArgs e)
        {
           // lblFristNamelook.Text = "Planned";

            lblFristNamelook.Text = "Planned";

            foreach (Control ctrl in flowLayoutPanel1.Controls)
            {
                if (ctrl is TasksItem task) task.Visible = task.IsPlanned;
            }

            foreach (Control ctrl in flowLayoutPanel2.Controls)
            {
                if (ctrl is TasksItem task) task.Visible = task.IsPlanned;
            }



            //foreach (Control ctrl in flowLayoutPanel1.Controls)
            //{
            //    if (ctrl is TasksItem task)
            //    {
            //        if (task.IsPlanned == true)
            //        {
            //            task.Visible = true;
            //            task.BackColor = Color.Red; // السطر ده هيفضحلنا مين اللي بيتعملها Planned غصب عننا
            //        }
            //        else
            //        {
            //            task.Visible = false;
            //        }
            //    }
            //}
        }

        private void guna2TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnlmid_Paint(object sender, PaintEventArgs e)
        {

        }

        private void guna2TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        //bool isMoved = false; // متغير لتتبع حالة الحركة
        //private void gunbtnClosePnlRight_Click(object sender, EventArgs e)
        //{
        //    // الكود ده بيخفي البانل
        //    pnlRight.Visible = !pnlRight.Visible;

        //    // (لو الأداة لسه ماتحركتش)
        //    //if (isMoved == false)
        //    //{
        //    //    gunbtnClosePnlRight.Location = new Point(841, 48);
        //    //    isMoved = true;
        //    //}
        //    //// لو الأداة كانت متحركة أصلاً
        //    //else
        //    //{
        //    //    gunbtnClosePnlRight.Location = new Point(307, 48);
        //    //    isMoved = false;
        //    //}
        //}
    }
}
//849, 48
//305,48
///*بص هو زرار ال All ده فيه كل ال tasks                                               
///وزرار ال myday بيكون فيه ال tasks بتاعت ال نهارده ال tasks ال معاداش عليها 24ساعه
/// ده ال بيكون عليه النجمه متعلم عليهاimportant وزرار بتاع ال 
/// وزرار ال planned ده ال بيعمله المستخدم كل يوم وبيظهر في ال my day ,all علي طوال البيكتب فيه
/// وزار ال tasks ده المهام ال مقفوال عليا مش بتظهر ولا في ال myday ولا ال all 
/// */
